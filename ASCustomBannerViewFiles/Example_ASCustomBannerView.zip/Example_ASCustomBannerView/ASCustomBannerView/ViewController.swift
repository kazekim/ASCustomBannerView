//
//  ViewController.swift
//  ASCustomBannerView
//
//  Created by Alan Roldán Maillo on 25/6/16.
//  Copyright © 2016 Alan Roldán Maillo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var baner: BannerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //at this step, you download images from a URL or local directory
        let imageName = ["bnr1","bnr2","bnr3","bnr5"]
        
        //you create array of type UIImage
        var arrayImages = [UIImage]()
        for i in 0 ... imageName.count-1
        {
            arrayImages.append(UIImage(named: imageName[i])!)
        }
        
        //instance the class BannerView
        baner.createBanner(arrayImages, widthScreen: UIScreen.mainScreen().bounds.width)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

